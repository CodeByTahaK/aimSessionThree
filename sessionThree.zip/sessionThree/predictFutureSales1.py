# Step 1: Load and Inspect the Data

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
import xgboost as xgb
from textblob import TextBlob
import matplotlib.pyplot as plt
import numpy as np

# Load datasets
products_df = pd.read_csv("Amazon Products.csv")
reviews_df = pd.read_csv("Amazon Reviews.csv")

# Preview first few rows
print("Products Sample:")
print(products_df.head())

print("\nReviews Sample:")
print(reviews_df.head())

# Check shapes of dataframes
print("\nProducts shape:", products_df.shape)
print("Reviews shape:", reviews_df.shape)

# Check for missing values
print("\nMissing values in Products:")
print(products_df.isnull().sum())

print("\nMissing values in Reviews:")
print(reviews_df.isnull().sum())

# Step 2: Clean and Aggregate Reviews

# Drop product rows with missing Future_Sales
products_df = products_df.dropna(subset=["Future_Sales"])

# Fill missing helpful votes with 0
reviews_df["Helpful Votes"] = reviews_df["Helpful Votes"].fillna(0)

# Step 2.5: Improved Sentiment Scoring using TextBlob

def advanced_sentiment(text):
    if pd.isnull(text):
        return 0
    blob = TextBlob(text)
    return blob.sentiment.polarity

# Apply sentiment scoring to each review
reviews_df["Sentiment_Score"] = reviews_df["Review Text"].apply(advanced_sentiment)

# Step 2.6: Aggregate Reviews with Sentiment

aggregated_reviews = reviews_df.groupby("asin").agg({
    "Rating": "mean",
    "Helpful Votes": "sum",
    "Review Text": "count",
    "Sentiment_Score": "mean"
}).rename(columns={
    "Rating": "Avg_Rating",
    "Helpful Votes": "Total_Helpful_Votes",
    "Review Text": "Review_Count",
    "Sentiment_Score": "Avg_Sentiment_Score"
})

# Reset index
aggregated_reviews = aggregated_reviews.reset_index()

# Merge the aggregated review data into the products dataframe
merged_df = pd.merge(products_df, aggregated_reviews, on="asin", how="left")

print("\nMerged Dataset Sample:")
print(merged_df.head())

# Step 3: Prepare Dataset for Modeling

# Remove products with Price = 0
merged_df = merged_df[merged_df["Price"] > 0]

# One-hot encode 'Brand'
merged_df = pd.get_dummies(merged_df, columns=["Brand"], drop_first=True)

# Select features (X) and target (y)
feature_columns = [
    "Price", "Total Reviews", "Avg_Rating", "Total_Helpful_Votes", "Review_Count", "Avg_Sentiment_Score"
] + [col for col in merged_df.columns if col.startswith("Brand_")]

X = merged_df[feature_columns]
y = merged_df["Future_Sales"]

print("\nFeature Columns:", feature_columns)
print("\nX Sample:")
print(X.head())

print("\nTarget y Sample:")
print(y.head())

# Step 4: Train/Test Split and Modeling

# Split into training and testing sets (70/30)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Train a Random Forest Regressor
random_forest = RandomForestRegressor(n_estimators=100, max_depth=5, random_state=42)
random_forest.fit(X_train, y_train)
print("\nRandom Forest R^2 on Test Set:", random_forest.score(X_test, y_test))

# Train an XGBoost Regressor
xgb_model = xgb.XGBRegressor(n_estimators=100, max_depth=5, learning_rate=0.1, random_state=42)
xgb_model.fit(X_train, y_train)
print("XGBoost R^2 on Test Set:", xgb_model.score(X_test, y_test))

# Step 5: Feature Importance Analysis

# Feature importance for XGBoost
xgb_importance = xgb_model.feature_importances_
indices = np.argsort(xgb_importance)[::-1]

print("\nXGBoost Feature Importances:")
for idx in indices:
    print(f"{feature_columns[idx]}: {xgb_importance[idx]:.4f}")

# Plot feature importances
plt.figure(figsize=(12, 8))
plt.title("Feature Importances (XGBoost)")
plt.bar(range(X.shape[1]), xgb_importance[indices], align="center")
plt.xticks(range(X.shape[1]), [feature_columns[i] for i in indices], rotation=90)
plt.tight_layout()
plt.show()
